﻿<?php
$servername = "database-1.choesk2e6xa8.us-east-2.rds.amazonaws.com"; // o el nombre de tu servidor si es diferente
$username = "OmarROA"; // Cambia según tu configuración de usuario
$password = "Pelana78123"; // Cambia si tienes una contraseña configurada
$dbname = "registros"; // Cambia al nombre de tu base de datos

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

?>
