// Cargar los productos del carrito
function loadCart() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartItems = document.getElementById("cartItems");
    const cartTotal = document.getElementById("cartTotal");

    // Limpiar el carrito antes de cargarlo
    cartItems.innerHTML = "";

    let total = 0;

    // Crear una tarjeta para cada producto en el carrito
    cart.forEach(item => {
        const cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");

        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}" style="width: 100px; height: auto;">
            <h3>${item.name}</h3>
            <p>Talla: ${item.size}</p>
            <p>Precio: $${item.price}</p>
            <p>Cantidad: ${item.quantity}</p>
            <button onclick="removeFromCart('${item.name}', '${item.size}', '${item.gender}')">Eliminar</button>
        `;

        cartItems.appendChild(cartItem);

        // Sumar el precio total
        total += item.price * item.quantity;
    });

    // Actualizar el total
    cartTotal.textContent = total.toFixed(2);
}

// Eliminar producto del carrito
function removeFromCart(name, size, gender) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart = cart.filter(item => !(item.name === name && item.size === size && item.gender === gender));

    localStorage.setItem("cart", JSON.stringify(cart));

    // Recargar los productos del carrito
    loadCart();
}

// Llamar a loadCart cuando la página se carga
window.onload = function() {
    loadCart();
};
