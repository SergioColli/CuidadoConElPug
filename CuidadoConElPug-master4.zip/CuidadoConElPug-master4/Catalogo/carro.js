document.getElementById("myButton1").onclick = function() {
    // Redirige a la página especificada
    window.location.href = "carrito.html"; // Asegúrate de que esta ruta sea correcta
};
